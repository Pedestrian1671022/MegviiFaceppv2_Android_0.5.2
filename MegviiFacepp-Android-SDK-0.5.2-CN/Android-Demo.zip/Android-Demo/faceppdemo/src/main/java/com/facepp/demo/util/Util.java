package com.facepp.demo.util;

public class Util {

	//在这边填写 API_KEY 和 API_SECRET
	public static String API_KEY = "";
	public static String API_SECRET = "";
	
	public static String CN_LICENSE_URL = "https://api-cn.faceplusplus.com/sdk/v2/auth";
	public static String US_LICENSE_URL = "https://api-us.faceplusplus.com/sdk/v2/auth";
}
